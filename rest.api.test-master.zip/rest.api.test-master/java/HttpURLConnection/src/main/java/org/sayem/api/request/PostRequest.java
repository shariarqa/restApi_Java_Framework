package org.sayem.api.request;

/**
 * Created by syed.sayem on 6/23/15.
 */
public class PostRequest {

    private String name;
    private String password;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
