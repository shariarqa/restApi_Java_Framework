package com.api.core.utils;

public class RequestConstants {

    public static final String REQUEST_OBJ="requestObj";
    public static final String LAT="lat";
    public static final String LON="lon";
    public static final String APPID="APPID";
    public static final String ZIP_CODE = "zip";
    public static final String REQUEST = "Request";
}
