package com.api.core.utils;

public class ResponseConstants {
    public static final Integer STATUS_CODE_OK = 200;
    public static final String RESPONSE = "Response";
    public static final String RESPONSE_TIME = "ResponseTime";
}
