package com.api.core.utils;

public class Constants {



    public static final String TEST_CASE_DIR = "/testData/";
    public static final String JSON_EXT = ".json";

    public static final String LOCATION = "location";
    public static final String STATUS_CODE = "StatusCode";
}
