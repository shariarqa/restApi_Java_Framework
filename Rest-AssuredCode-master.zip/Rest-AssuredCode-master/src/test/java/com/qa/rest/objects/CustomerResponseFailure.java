package com.qa.rest.objects;

public class CustomerResponseFailure {
	
	public String FaultId;
	public String fault;
	
	

}
