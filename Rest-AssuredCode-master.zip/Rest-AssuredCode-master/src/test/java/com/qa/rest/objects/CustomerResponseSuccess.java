package com.qa.rest.objects;

public class CustomerResponseSuccess {
	
	public String SuccessCode;
	public String Message;
	
//	{
//	    "SuccessCode": "OPERATION_SUCCESS",
//	    "Message": "Operation completed successfully"
//	}
	
	
	

}
